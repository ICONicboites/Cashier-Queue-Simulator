import React, { useState } from 'react'

export default function CustomerQueue({ queue, onAdd, onAssignOne, onAssignAll }) {
  const [name, setName] = useState('')
  const [type, setType] = useState('normal')

  function handleAdd() {
    if (!name.trim()) return
    onAdd(name, type)
    setName('')
  }

  return (
    <div className="card queue-card">
      <h2>Cashier Queue</h2>

      <div className="add-row">
        <input
          aria-label="Customer name"
          placeholder="Enter customer name"
          value={name}
          onChange={e => setName(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && handleAdd()}
        />
        <select value={type} onChange={e => setType(e.target.value)}>
          <option value="normal">Normal</option>
          <option value="priority">Priority</option>
        </select>
        <button className="btn" onClick={handleAdd}>Add Customer</button>
      </div>

      <div className="queue-panel">
        <div className="waiting-title">Waiting Queue</div>
        <div className="queue-list">
          {queue.length === 0 ? (
            <div className="empty">No customers waiting.</div>
          ) : (
            <ol>
              {queue.map(c => (
                <li key={c.id}>
                  <span className="dot" style={{ background: c.color }} />
                  <span className="q-text">ID: {c.id} | {c.name} ({c.serviceTime}s)</span>
                </li>
              ))}
            </ol>
          )}
        </div>
      </div>

      <div className="actions">
        <button className="btn primary" onClick={onAssignOne} disabled={queue.length === 0}>
          Assign Customer
        </button>
        <button className="btn" onClick={onAssignAll} disabled={queue.length === 0}>
          Assign All
        </button>
      </div>
    </div>
  )
}
