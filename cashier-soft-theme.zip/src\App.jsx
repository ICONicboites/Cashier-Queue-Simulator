import React, { useState, useRef, useEffect } from 'react'
import CustomerQueue from './components/CustomerQueue'
import CashierCard from './components/CashierCard'

export default function App() {
  const [queue, setQueue] = useState([]) // waiting queue (FIFO)
  const nextId = useRef(1)

  const [cashiers, setCashiers] = useState([
    { id: 1, name: 'Priority Cashier', type: 'priority', current: null, queue: [] },
    { id: 2, name: 'Normal Cashier', type: 'regular', current: null, queue: [] },
    { id: 3, name: 'Normal Cashier', type: 'regular', current: null, queue: [] }
  ])

  // helper to create a customer object
  function createCustomer(name, type) {
    const id = nextId.current++
    const serviceTime = Math.floor(Math.random() * 96) + 5 // 5-100 seconds
    const color = type === 'priority' ? '#ef4444' : '#2563eb' // red for priority, blue for normal
    return { id, name, type, serviceTime, color }
  }

  function addCustomer(name, type = 'normal') {
    if (!name || !name.trim()) return
    const c = createCustomer(name.trim(), type)
    setQueue(prev => [...prev, c])
  }

  // compute load = (current ? 1 : 0) + queue.length
  function cashierLoad(c) {
    return (c.current ? 1 : 0) + c.queue.length
  }

  // choose cashier according to customer type and rules
  function chooseCashierFor(customer) {
    if (!customer) return null

    if (customer.type === 'priority') {
      const priorityCashiers = cashiers.filter(c => c.type === 'priority')
      if (priorityCashiers.length > 0) {
        return priorityCashiers.reduce((best, c) => (cashierLoad(c) < cashierLoad(best) ? c : best), priorityCashiers[0])
      }
    }

    // normal customer: prefer regular cashiers
    const regulars = cashiers.filter(c => c.type === 'regular')
    if (regulars.length > 0) {
      // if any regulars, pick the one with least load
      let best = regulars.reduce((b, c) => (cashierLoad(c) < cashierLoad(b) ? c : b), regulars[0])
      // if the best regular has load > 0 but some priority cashier is idle, allow assignment to idle priority
      const idlePriority = cashiers.find(c => c.type === 'priority' && cashierLoad(c) === 0)
      if (idlePriority && cashierLoad(best) > 0) return idlePriority
      return best
    }

    // fallback: choose any cashier with least load
    return cashiers.reduce((best, c) => (cashierLoad(c) < cashierLoad(best) ? c : best), cashiers[0])
  }

  function assignOne() {
    if (queue.length === 0) {
      alert('No customers in queue')
      return
    }

    const [nextCustomer, ...rest] = queue

    const chosen = chooseCashierFor(nextCustomer)
    if (!chosen) return

    setCashiers(prev =>
      prev.map(c => {
        if (c.id === chosen.id) {
          if (!c.current) {
            return { ...c, current: { ...nextCustomer, remaining: nextCustomer.serviceTime } }
          }
          return { ...c, queue: [...c.queue, nextCustomer] }
        }
        return c
      })
    )

    setQueue(rest)
  }

  function assignAll() {
    if (queue.length === 0) {
      alert('No customers in queue')
      return
    }
    // Greedy assign until queue empty
    let q = [...queue]
    while (q.length > 0) {
      const customer = q.shift()
      const chosen = chooseCashierFor(customer)
      if (!chosen) break
      setCashiers(prev =>
        prev.map(c => {
          if (c.id === chosen.id) {
            if (!c.current) {
              return { ...c, current: { ...customer, remaining: customer.serviceTime } }
            }
            return { ...c, queue: [...c.queue, customer] }
          }
          return c
        })
      )
    }
    setQueue([])
  }

  // ticking timer: decrement remaining seconds for each cashier every second
  useEffect(() => {
    const t = setInterval(() => {
      setCashiers(prev =>
        prev.map(c => {
          if (!c.current) return c
          const nextRemaining = (c.current.remaining || c.current.serviceTime) - 1
          if (nextRemaining > 0) {
            return { ...c, current: { ...c.current, remaining: nextRemaining } }
          }
          // current finished — move next in cashier queue to current
          if (c.queue.length > 0) {
            const [nextCust, ...restQueue] = c.queue
            return { ...c, current: { ...nextCust, remaining: nextCust.serviceTime }, queue: restQueue }
          }
          return { ...c, current: null }
        })
      )
    }, 1000)
    return () => clearInterval(t)
  }, [])

  return (
    <div className="app-root">
      <header className="app-header">
        <h1>Cashier Queue Simulator</h1>
      </header>

      <main className="dashboard">
        <div className="queue-top">
          <CustomerQueue
            queue={queue}
            onAdd={addCustomer}
            onAssignOne={assignOne}
            onAssignAll={assignAll}
          />
        </div>

        <section className="cashiers-row">
          <div className="cashiers-grid">
            {cashiers.map(c => (
              <CashierCard key={c.id} cashier={c} />
            ))}
          </div>
        </section>
      </main>
    </div>
  )
}
