import React from 'react'

export default function CashierCard({ cashier }) {
  return (
    <div className="card cashier-card">
      <div className="cashier-header">
        <h3>{cashier.name}</h3>
        <div className="count">{(cashier.current ? 1 : 0) + cashier.queue.length}</div>
      </div>

      <div className="serving">
        {cashier.current ? (
          <div className="now-serving">
            <div className="ns-title">Now serving</div>
            <div className="ns-name">
              <span className="dot" style={{ background: cashier.current.color }} />
              {cashier.current.name} (ID: {cashier.current.id})
            </div>
            <div className="ns-remaining">{cashier.current.remaining}s remaining</div>
          </div>
        ) : (
          <div className="empty">Idle Cashier</div>
        )}
      </div>

      <div className="cashier-queue">
        <div className="cq-title">Queue</div>
        {cashier.queue.length === 0 ? (
          <div className="empty">No queue</div>
        ) : (
          <ol>
            {cashier.queue.map(c => (
              <li key={c.id}>
                <span className="dot" style={{ background: c.color }} />
                <span className="q-text">{c.name} ({c.serviceTime}s)</span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </div>
  )
}
